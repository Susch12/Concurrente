package problemas;

import java.util.concurrent.Semaphore;

public class BarberoDormilon {

    private static final int NUM_SILLAS_ESPERA = 3;
    private static final Semaphore clientes = new Semaphore(0); // Clientes esperando
    private static final Semaphore barbero = new Semaphore(0); // Barbero disponible
    private static final Semaphore accesoSala = new Semaphore(1); // Exclusión mutua
    private static int clientesEsperando = 0;

    public static void iniciar() {
        new Thread(BarberoDormilon::barbero).start();

        // Simular llegada de varios clientes
        for (int i = 0; i < 10; i++) {
            int id = i;
            new Thread(() -> cliente(id)).start();
            try {
                Thread.sleep((int)(Math.random() * 2000)); // Llegada aleatoria
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    private static void barbero() {
        while (true) {
            try {
                clientes.acquire(); // Espera por un cliente
                accesoSala.acquire();
                clientesEsperando--;
                System.out.println("💈 El barbero está cortando el cabello...");
                barbero.release(); // Deja pasar al cliente
                accesoSala.release();

                Thread.sleep(3000); // Cortar cabello
                System.out.println("✅ El barbero terminó de cortar el cabello.");

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    private static void cliente(int id) {
        try {
            accesoSala.acquire();
            if (clientesEsperando < NUM_SILLAS_ESPERA) {
                clientesEsperando++;
                System.out.println("🧑 Cliente " + id + " se sienta a esperar.");
                clientes.release(); // Notifica al barbero
                accesoSala.release();

                barbero.acquire(); // Espera a ser atendido
                System.out.println("✂️ Cliente " + id + " está siendo atendido.");

            } else {
                System.out.println("🚶 Cliente " + id + " se fue porque no hay sillas.");
                accesoSala.release();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
