package problemas;

import java.util.Random;
import java.util.concurrent.Semaphore;

public class Fumadores {

    private static final Semaphore mutex = new Semaphore(1);

    // Semáforos para los 3 fumadores
    private static final Semaphore tienePapelYTabaco = new Semaphore(0);
    private static final Semaphore tienePapelYCerillos = new Semaphore(0);
    private static final Semaphore tieneTabacoYCerillos = new Semaphore(0);

    private static final Random random = new Random();

public static void iniciar() {
    new Thread(new Fumador("Fumador con cerillos", tienePapelYTabaco)).start();
    new Thread(new Fumador("Fumador con tabaco", tienePapelYCerillos)).start();
    new Thread(new Fumador("Fumador con papel", tieneTabacoYCerillos)).start();

    new Thread(() -> {
        while (true) {
            try {
                mutex.acquire();
                int eleccion = random.nextInt(3);
                switch (eleccion) {
                    case 0 -> tienePapelYTabaco.release();
                    case 1 -> tienePapelYCerillos.release();
                    case 2 -> tieneTabacoYCerillos.release();
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }).start();
}

    static class Fumador implements Runnable {
        private final String nombre;
        private final Semaphore miTurno;

        public Fumador(String nombre, Semaphore miTurno) {
            this.nombre = nombre;
            this.miTurno = miTurno;
        }

        public void run() {
            while (true) {
                try {
                    miTurno.acquire(); // Espera su turno
                    System.out.println("🚬 " + nombre + " está fumando...");
                    Thread.sleep(1000); // Simula fumar
                    mutex.release(); // Libera para que el agente ponga más ingredientes
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }
}
