package problemas;

import java.util.concurrent.Semaphore;

public class Filosofos {

    private static final int NUM_FILOSOFOS = 5;
    private static final Semaphore[] tenedores = new Semaphore[NUM_FILOSOFOS];

    public static void iniciar() {
        // Inicializar los semáforos (tenedores)
        for (int i = 0; i < NUM_FILOSOFOS; i++) {
            tenedores[i] = new Semaphore(1);
        }

        // Crear e iniciar hilos para cada filósofo
        for (int i = 0; i < NUM_FILOSOFOS; i++) {
            int id = i;
            new Thread(() -> filosofo(id)).start();
        }
    }

    private static void filosofo(int id) {
        try {
            while (true) {
                pensar(id);
                tomarTenedores(id);
                comer(id);
                soltarTenedores(id);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private static void pensar(int id) throws InterruptedException {
        System.out.println("🧠 Filósofo " + id + " está pensando.");
        Thread.sleep((long) (Math.random() * 2000));
    }

    private static void tomarTenedores(int id) throws InterruptedException {
        tenedores[id].acquire(); // Tenedor izquierdo
        tenedores[(id + 1) % NUM_FILOSOFOS].acquire(); // Tenedor derecho
        System.out.println("🍴 Filósofo " + id + " tomó ambos tenedores.");
    }

    private static void comer(int id) throws InterruptedException {
        System.out.println("🍝 Filósofo " + id + " está comiendo.");
        Thread.sleep((long) (Math.random() * 2000));
    }

    private static void soltarTenedores(int id) {
        tenedores[id].release();
        tenedores[(id + 1) % NUM_FILOSOFOS].release();
        System.out.println("🙌 Filósofo " + id + " soltó los tenedores.");
    }
}
