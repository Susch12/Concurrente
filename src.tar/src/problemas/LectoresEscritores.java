package problemas;

public class LectoresEscritores {

    private static int lectoresActivos = 0;
    private static boolean escritorActivo = false;
    private static final Object monitor = new Object();

    public static void iniciar() {
        // Lanzar 3 lectores y 2 escritores
        for (int i = 0; i < 3; i++) {
            int id = i;
            new Thread(() -> lector(id)).start();
        }

        for (int i = 0; i < 2; i++) {
            int id = i;
            new Thread(() -> escritor(id)).start();
        }
    }

    private static void lector(int id) {
        while (true) {
            try {
                synchronized (monitor) {
                    while (escritorActivo) {
                        monitor.wait(); // Espera si hay un escritor escribiendo
                    }
                    lectoresActivos++;
                }

                System.out.println("📖 Lector " + id + " está leyendo.");
                Thread.sleep((long) (Math.random() * 2000));

                synchronized (monitor) {
                    lectoresActivos--;
                    System.out.println("✅ Lector " + id + " terminó de leer.");
                    if (lectoresActivos == 0) {
                        monitor.notifyAll(); // Avisar a escritores
                    }
                }

                Thread.sleep((long) (Math.random() * 3000)); // Tiempo antes de volver a leer

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    private static void escritor(int id) {
        while (true) {
            try {
                synchronized (monitor) {
                    while (escritorActivo || lectoresActivos > 0) {
                        monitor.wait(); // Espera si hay alguien leyendo o escribiendo
                    }
                    escritorActivo = true;
                }

                System.out.println("📝 Escritor " + id + " está escribiendo.");
                Thread.sleep((long) (Math.random() * 3000));

                synchronized (monitor) {
                    escritorActivo = false;
                    System.out.println("✍️ Escritor " + id + " terminó de escribir.");
                    monitor.notifyAll(); // Avisar a lectores y escritores
                }

                Thread.sleep((long) (Math.random() * 3000)); // Tiempo antes de volver a escribir

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}
