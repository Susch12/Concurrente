package problemas;

import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.Semaphore;

public class productor_consumidor {

    // Buffer compartido
    private static final int CAPACIDAD = 5;
    private static final Queue<Integer> buffer = new LinkedList<>();

    // Semáforos para controlar el acceso
    private static final Semaphore mutex = new Semaphore(1);               // Exclusión mutua
    private static final Semaphore items = new Semaphore(0);               // Contar ítems disponibles
    private static final Semaphore espacios = new Semaphore(CAPACIDAD);    // Espacios disponibles

    public static void main(String[] args) {
        Thread productor = new Thread(new Productor(), "Productor");
        Thread consumidor = new Thread(new Consumidor(), "Consumidor");

        productor.start();
        consumidor.start();
    }
    public static void iniciar() {
    Thread productor = new Thread(new Productor(), "Productor");
    Thread consumidor = new Thread(new Consumidor(), "Consumidor");
    productor.start();
    consumidor.start();
}


    static class Productor implements Runnable {
        private int valor = 0;

        public void run() {
            try {
                while (true) {
                    espacios.acquire();         // Espera un espacio libre
                    mutex.acquire();            // Entra a la sección crítica

                    buffer.add(valor);
                    System.out.println("🟢 " + Thread.currentThread().getName() + " produjo: " + valor);
                    valor++;

                    mutex.release();            // Sale de la sección crítica
                    items.release();            // Señala que hay un nuevo ítem

                    Thread.sleep(1000);         // Simula tiempo de producción
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    static class Consumidor implements Runnable {
        public void run() {
            try {
                while (true) {
                    items.acquire();            // Espera que haya ítems disponibles
                    mutex.acquire();            // Entra a la sección crítica

                    int valor = buffer.poll();
                    System.out.println("🔴 " + Thread.currentThread().getName() + " consumió: " + valor);

                    mutex.release();            // Sale de la sección crítica
                    espacios.release();         // Señala que hay un nuevo espacio libre

                    Thread.sleep(1500);         // Simula tiempo de consumo
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}
