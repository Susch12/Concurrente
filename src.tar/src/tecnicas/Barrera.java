package tecnicas;

import java.util.concurrent.CyclicBarrier;

public class Barrera {

    private static final int NUM_HILOS = 3;
    private static final CyclicBarrier barrera = new CyclicBarrier(NUM_HILOS, () -> System.out.println("🚀 Todos listos, avanzamos juntos!"));

    public void ejecutar() {
        for (int i = 0; i < NUM_HILOS; i++) {
            int id = i;
            new Thread(() -> {
                try {
                    System.out.println("🧵 Hilo " + id + " listo y esperando.");
                    Thread.sleep((long) (Math.random() * 2000));
                    barrera.await();
                    System.out.println("▶️ Hilo " + id + " cruzó la barrera.");
                } catch (Exception e) {
                    Thread.currentThread().interrupt();
                }
            }).start();
        }
    }
}
