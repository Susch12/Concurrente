package tecnicas;

import java.util.concurrent.Semaphore;

public class Semaforo {

    private final Semaphore semaforo = new Semaphore(1); // 1 permiso, exclusivo

    public void ejecutar() {
        try {
            semaforo.acquire();
            System.out.println("🎯 Accediendo con semáforo...");
            Thread.sleep(2000); // Simula trabajo
            System.out.println("✅ Acceso terminado.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            semaforo.release();
        }
    }
}
