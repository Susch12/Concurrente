package tecnicas;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class VariableCondicion {

    private final ReentrantLock lock = new ReentrantLock();
    private final Condition condicion = lock.newCondition();
    private boolean listo = false;

    public void ejecutar() {
        try {
            lock.lock();
            while (!listo) {
                System.out.println("⏸ Esperando condición...");
                condicion.await();
            }
            System.out.println("✅ Condición cumplida.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            lock.unlock();
        }
    }

    public void activar() {
        try {
            lock.lock();
            listo = true;
            condicion.signalAll(); // Despertamos a todos
        } finally {
            lock.unlock();
        }
    }
}
