package tecnicas;

public class Monitores {

    private static final Object monitor = new Object();

    public void ejecutar() {
        synchronized (monitor) {
            try {
                System.out.println("🧩 Accediendo con monitor...");
                Thread.sleep(2000); // Simula trabajo
                System.out.println("✅ Acceso terminado.");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}
