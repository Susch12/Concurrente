package GUI;

import problemas.*;
import tecnicas.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class MainMenu extends JFrame {

    private JComboBox<String> comboProblemas;
    private JComboBox<String> comboTecnicas;
    private JButton botonEjecutar;
    private PanelGrafoHilos panelGrafo;
    private PanelDiagramaHilos panelDiagrama;


    public MainMenu() {
        setTitle("Simulador de Problemas de Sincronización");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        initComponents();
    }

    private void initComponents() {
        String[] problemas = {
            "Productor/Consumidor",
            "Filosofos",
            "Barbero Dormilón",
            "Fumadores",
            "Lectores/Escritores"
        };

        String[] tecnicas = {
            "Semáforo",
            "Variable de condición",
            "Monitor",
            "Barrera"
        };

        comboProblemas = new JComboBox<>(problemas);
        comboTecnicas = new JComboBox<>(tecnicas);
        botonEjecutar = new JButton("Ejecutar");

        botonEjecutar.addActionListener(this::ejecutarSimulacion);

        setLayout(new GridBagLayout());
        panelGrafo = new PanelGrafoHilos();
        panelGrafo.setPreferredSize(new Dimension(900, 500));
        panelGrafo.setBackground(Color.LIGHT_GRAY);

        panelDiagrama = new PanelDiagramaHilos();
        panelDiagrama.setPreferredSize(new Dimension(900, 100));
        panelDiagrama.setBorder(BorderFactory.createTitledBorder("Diagrama de Hilos"));


        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        gbc.gridx = 0; gbc.gridy = 0;
        add(new JLabel("Selecciona un problema:"), gbc);

        gbc.gridx = 1;
        add(comboProblemas, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        add(new JLabel("Selecciona una técnica:"), gbc);

        gbc.gridx = 1;
        add(comboTecnicas, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        add(botonEjecutar, gbc);

        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        add(panelGrafo, gbc);

        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        add(panelDiagrama, gbc);
    }

    private void ejecutarSimulacion(ActionEvent e) {
        String problema = (String) comboProblemas.getSelectedItem();
        String tecnica = (String) comboTecnicas.getSelectedItem();

        // Limpiar grafo
        panelGrafo.limpiarPanel();

        // Ejecutar según el problema
        switch (problema) {
            case "Productor/Consumidor":
                panelGrafo.agregarProcesosYRecursos(2, 1);
                productor_consumidor.iniciar();
                break;
            case "Filosofos":
                panelGrafo.agregarProcesosYRecursos(5, 5);
                Filosofos.iniciar();
                break;
            case "Barbero Dormilón":
                panelGrafo.agregarProcesosYRecursos(6, 1);
                BarberoDormilon.iniciar();
                break;
            case "Fumadores":
                panelGrafo.agregarProcesosYRecursos(4, 0);
                Fumadores.iniciar();
                break;
            case "Lectores/Escritores":
                panelGrafo.agregarProcesosYRecursos(3, 1);
                LectoresEscritores.iniciar();
                break;
            default:
                JOptionPane.showMessageDialog(this, "Problema no soportado aún.");
        }

        // Ejecutar según la técnica
        switch (tecnica) {
            case "Semáforo":
                new Semaforo().ejecutar();
                break;
            case "Variable de condición":
                VariableCondicion condicion = new VariableCondicion();
                condicion.ejecutar();
                condicion.activar();
                break;
            case "Monitor":
                new Monitores().ejecutar();
                break;
            case "Barrera":
                new Barrera().ejecutar();
                break;
            default:
                JOptionPane.showMessageDialog(this, "🚧 Técnica no soportada.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainMenu().setVisible(true));
    }
} 


