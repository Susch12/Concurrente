package GUI;

import javax.swing.*;
import java.awt.*;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class PanelDiagramaHilos extends JPanel implements Runnable {

    private final Map<String, EstadoHilo> hilos = new ConcurrentHashMap<>();
    private volatile boolean ejecutando = true;

    public PanelDiagramaHilos() {
        setBackground(Color.WHITE);
        Thread refrescador = new Thread(this);
        refrescador.setDaemon(true);
        refrescador.start();
    }

    public void actualizarEstado(String nombreHilo, EstadoHilo.Estado estado) {
        hilos.put(nombreHilo, new EstadoHilo(nombreHilo, estado));
        repaint();
    }

    public void detener() {
        ejecutando = false;
    }

    @Override
    public void run() {
        while (ejecutando) {
            repaint();
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        int y = 30;
        for (EstadoHilo hilo : hilos.values()) {
            g2d.setColor(Color.BLACK);
            g2d.drawString(hilo.nombre, 10, y);

            switch (hilo.estado) {
                case ACTIVO -> g2d.setColor(Color.GREEN);
                case BLOQUEADO -> g2d.setColor(Color.ORANGE);
                case FINALIZADO -> g2d.setColor(Color.RED);
            }
            g2d.fillRect(120, y - 15, 100, 15);
            y += 25;
        }
    }

    public static class EstadoHilo {
        public enum Estado {
            ACTIVO, BLOQUEADO, FINALIZADO
        }

        public final String nombre;
        public final Estado estado;

        public EstadoHilo(String nombre, Estado estado) {
            this.nombre = nombre;
            this.estado = estado;
        }
    }
} 
