package GUI;

public class Visualizador {
    public static PanelDiagramaHilos panelDiagrama;
    public static PanelGrafoHilos panelGrafo;
}
