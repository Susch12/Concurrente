package tecnicas.Filosofos;

public interface TecnicaSincronizacion {
    void ejecutar();
}