package tecnicas.Fumadores;

public interface TecnicaSincronizacion {
    void ejecutar();
}