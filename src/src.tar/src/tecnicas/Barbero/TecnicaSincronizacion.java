package tecnicas.Barbero;

public interface TecnicaSincronizacion {
    void ejecutar();
}