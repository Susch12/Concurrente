package tecnicas.PC;

public interface TecnicaSincronizacion {
    void ejecutar();
}