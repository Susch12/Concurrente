package tecnicas.Lectores;

public interface TecnicaSincronizacion {
    void ejecutar();
}